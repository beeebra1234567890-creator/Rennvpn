package com.example.wgclient

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class VpnState { DISCONNECTED, CONNECTING, CONNECTED }

/**
 * Единая точка управления туннелем. Два движка:
 *  - VLESS → [XrayVpnService] (Xray-core через libv2ray.aar);
 *  - WireGuard → GoBackend из официальной библиотеки.
 */
object VpnController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _state = MutableStateFlow(VpnState.DISCONNECTED)
    val state: StateFlow<VpnState> = _state.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    /** SystemClock.elapsedRealtime() в момент установки соединения. */
    private val _connectedAt = MutableStateFlow(0L)
    val connectedAt: StateFlow<Long> = _connectedAt.asStateFlow()

    private var wgBackend: GoBackend? = null
    private var activeProtocol: String = ""

    private val wgTunnel = object : Tunnel {
        override fun getName(): String = "rentvpn"
        override fun onStateChange(newState: Tunnel.State) {
            if (activeProtocol != "wireguard") return
            if (newState == Tunnel.State.UP) setState(VpnState.CONNECTED) else setState(VpnState.DISCONNECTED)
        }
    }

    private fun wg(context: Context): GoBackend =
        wgBackend ?: GoBackend(context.applicationContext).also { wgBackend = it }

    // ---- вызывается и из XrayVpnService ----
    internal fun setState(s: VpnState) {
        if (s == VpnState.CONNECTED) _connectedAt.value = SystemClock.elapsedRealtime()
        _state.value = s
    }

    internal fun fail(message: String) {
        _error.value = message
        _state.value = VpnState.DISCONNECTED
    }

    fun clearError() { _error.value = null }

    /** Разрешение VpnService уже должно быть выдано (VpnService.prepare). */
    fun connect(context: Context, server: Server) {
        if (_state.value != VpnState.DISCONNECTED) return
        val app = context.applicationContext
        _error.value = null
        _state.value = VpnState.CONNECTING
        activeProtocol = server.protocol

        when (server.protocol) {
            "vless" -> {
                val json = try {
                    VlessParser.parse(server.raw).toXrayJson()
                } catch (e: Exception) {
                    fail("Некорректная VLESS-ссылка: ${e.message}")
                    return
                }
                val intent = Intent(app, XrayVpnService::class.java)
                    .setAction(XrayVpnService.ACTION_START)
                    .putExtra(XrayVpnService.EXTRA_CONFIG, json)
                runCatching { ContextCompat.startForegroundService(app, intent) }
                    .onFailure { fail("Не удалось запустить VPN-сервис: ${it.message}") }
            }
            "wireguard" -> scope.launch {
                runCatching {
                    require(server.raw.contains("[Interface]") && server.raw.contains("[Peer]")) {
                        "Ожидается WireGuard-конфигурация с [Interface] и [Peer]"
                    }
                    val config = Config.parse(server.raw.byteInputStream())
                    wg(app).setState(wgTunnel, Tunnel.State.UP, config)
                }.onFailure { fail("Не удалось подключиться: ${it.message ?: "проверьте конфигурацию"}") }
            }
            else -> fail("Протокол ${server.protocol.uppercase()} не поддерживается")
        }
    }

    fun disconnect(context: Context) {
        val app = context.applicationContext
        when (activeProtocol) {
            "vless" -> {
                app.stopService(Intent(app, XrayVpnService::class.java))
                setState(VpnState.DISCONNECTED)
            }
            "wireguard" -> scope.launch {
                runCatching { wg(app).setState(wgTunnel, Tunnel.State.DOWN, null) }
                    .onFailure { _error.value = it.message ?: "Ошибка отключения" }
                setState(VpnState.DISCONNECTED)
            }
            else -> setState(VpnState.DISCONNECTED)
        }
    }
}
